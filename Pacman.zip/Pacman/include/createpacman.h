#ifndef _CREATEPACMAN_H_
#define _CREATEPACMAN_H_
#include <GL/glut.h>

void drawPacman(float positionX, float positionY, float rotation);

#endif