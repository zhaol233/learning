#ifndef _GAMESTART_H_
#define _GAMESTART_H_
#include <iterator>

void welcomeScreen();
void display();
void reshape(int w, int h);

#endif
