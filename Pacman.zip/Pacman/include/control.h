#ifndef _CONTROL_H_
#define _CONTROL_H_
void keyPressed(unsigned char key, int x, int y);
void keyUp(unsigned char key, int x, int y);
void resetGame();
void keyOperations();

#endif