#ifndef _MONSTER_H_
#define _MONSTER_H_
void drawMonster(float positionX, float positionY, float r, float g, float b);
void updateMonster(float* monster, int id);

#endif