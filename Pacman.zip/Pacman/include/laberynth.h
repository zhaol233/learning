#ifndef _LABERYTH_H
#define _LABERYTH_H
void drawLaberynth();

#endif