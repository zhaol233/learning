#ifndef _GAMERESULT_H_
#define _GAMERESULT_H_
#include <cstring>
#include <iterator>
void resultsDisplay();

#endif
