#ifndef _FOOD_H_
#define _FOOD_H_
#include <deque>

bool foodEaten(int x, int y, float pacmanX, float pacmanY);
void drawFood(float pacmanX, float pacmanY);


#endif